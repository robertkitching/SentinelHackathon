<template>
  <v-container>
    <v-row class="text-center">
      <v-col class="mb-4">
        <h1 class="display-2 font-weight-bold mb-3">
          Welcome to Sagi`s Project
        </h1>

        <p class="text-justify">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. It was popularised in the 1960s with
          the release of Letraset sheets containing Lorem Ipsum passages, and
          more recently with desktop publishing software like Aldus PageMaker
          including versions of Lorem Ipsum.
        </p>

        <v-expansion-panels>
          <v-expansion-panel>
            <v-expansion-panel-header disable-icon-rotate>
              Connection info
              <template v-slot:actions>
                <v-icon color="teal"> mdi-check </v-icon>
              </template>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-text-field
                v-model="appid"
                label="Application ID"
              ></v-text-field>
              <v-text-field
                v-model="secret"
                :type="password"
                label="Secret"
              ></v-text-field>
              <v-text-field v-model="tenant" label="Tenant"></v-text-field>
              <v-text-field v-model="subsid" label="Subid"></v-text-field>

              <v-btn
                :loading="loading"
                :disabled="loading"
                color="success"
                class="mr-4"
                @click="validate"
                >Validate</v-btn
              >
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>

        <v-select
          v-if="subscriptions"
          :items="subscriptions"
          item-text="label"
          item-value="id"
          v-model="subscription"
          label="Subscription"
          @change="selectSubscription"
        ></v-select>

        <v-select
          v-if="resources"
          :items="resources"
          item-text="label"
          item-value="id"
          v-model="resource"
          label="Resource Group"
          @change="selectResource"
        ></v-select>

        <v-select
          v-if="workspaces"
          :items="workspaces"
          item-text="label"
          item-value="id"
          v-model="workspace"
          label="Workspaces"
          @change="selectWorkspace"
        ></v-select>

        <v-select
          v-if="analitcs"
          :items="analitcs"
          item-text="label"
          item-value="id"
          v-model="analytic"
          label="Analytics rules"
          @change="selectAnalytics"
        ></v-select>

        <div v-if="analytic">
          <v-text-field v-model="entity" label="Entity"></v-text-field>

          <v-btn
            :loading="loading"
            :disabled="loading"
            color="success"
            class="mr-4"
            @click="sendEntity"
            >Send</v-btn
          >
          <div v-for="(action, index) in actions" :key="index">
            <v-text-field
              v-model="action.value"
              :label="`Action ${index}`"
              hint="use {ip} for value"
            ></v-text-field>
          </div>
          <v-btn
            class="mx-2"
            fab
            dark
            small
            color="primary"
            @click="changeAction('minus')"
          >
            <v-icon dark> mdi-minus </v-icon>
          </v-btn>
          <v-btn
            class="mx-2"
            fab
            dark
            small
            color="indigo"
            @click="changeAction('plus')"
          >
            <v-icon dark> mdi-plus </v-icon>
          </v-btn>
          <v-text-field
            v-model="hostAction"
            label="Please add HTTP POST URL "
          ></v-text-field>

          <v-checkbox v-model="teams" :label="`Teams`"></v-checkbox>

          <v-text-field
            v-if="teams"
            v-model="teamstext"
            label="Please add Teams "
          ></v-text-field>

          <div v-for="(query, index) in queries" :key="index">
            <v-textarea
              v-model="query.value"
              :label="`Query ${index}`"
              hint="use {ip} for value"
            ></v-textarea>
          </div>

          <v-btn
            class="mx-2"
            fab
            dark
            small
            color="primary"
            @click="changeQuery('minus')"
          >
            <v-icon dark> mdi-minus </v-icon>
          </v-btn>
          <v-btn
            class="mx-2"
            fab
            dark
            small
            color="indigo"
            @click="changeQuery('plus')"
          >
            <v-icon dark> mdi-plus </v-icon>
          </v-btn>

          <v-btn color="success" class="mr-4" @click="sendQueries"
            >Send Queries</v-btn
          >
        </div>

        <v-progress-circular
          v-if="showLoader"
          indeterminate
          color="primary"
        ></v-progress-circular>

        <v-card>
          <v-card-title class="blue white--text">
            <span class="text-h5">Menu</span>

            <v-spacer></v-spacer>

            <v-menu bottom left>
              <template v-slot:activator="{ on, attrs }">
                <v-btn dark icon v-bind="attrs" v-on="on">
                  <v-icon>mdi-dots-vertical</v-icon>
                </v-btn>
              </template>

              <v-list>
                <v-list-item v-for="(item, i) in items" :key="i">
                  <v-list-item-title @click="selectActionMenu(item)">{{
                    item.title
                  }}</v-list-item-title>
                </v-list-item>
              </v-list>
            </v-menu>
          </v-card-title>
          <v-toolbar color="cyan" dark flat>
            <template v-slot:extension>
              <v-tabs v-model="model" centered slider-color="yellow">
                <v-tab v-for="i in queriesCount" :key="i" :href="`#tab-${i}`">
                  Item {{ i }}
                </v-tab>
              </v-tabs>
            </template>
          </v-toolbar>

          <v-tabs-items v-model="model">
            <v-tab-item v-for="i in queriesCount" :key="i" :value="`tab-${i}`">
              <v-card flat>
                <v-data-table
                  :headers="headers"
                  :items="desserts"
                  :items-per-page="5"
                  class="elevation-1"
                  :loading="loadingTable"
                  loading-text="Loading... Please wait"
                  :single-select="true"
                  item-key="name"
                  show-select
                ></v-data-table>
                <v-card-text v-text="text"></v-card-text>
              </v-card>
            </v-tab-item>
          </v-tabs-items>
        </v-card>
      </v-col>

      <v-dialog v-model="dialog" scrollable max-width="300px">
        <v-card>
          <v-card-title>Select Action</v-card-title>
          <v-divider></v-divider>
          <v-card-text style="height: 300px">
            <v-radio-group v-model="dialogm1" column>
              <div v-for="(action, index) in actions" :key="index">
                <v-radio :label="action.value" :value="action.value"></v-radio>
              </div>
            </v-radio-group>
          </v-card-text>
          <v-divider></v-divider>
          <v-card-actions>
            <v-btn color="blue darken-1" text @click="dialog = false">
              Close
            </v-btn>
            <v-btn color="blue darken-1" text @click="dialog = false">
              Submit
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "MainForm",

  data: () => ({
    teams: false,
    teamstext: "",
    dialog: false,
    items: [
      { title: "Click Me" },
      { title: "Click Me" },
      { title: "Click Me" },
      { title: "Click Me 2" },
    ],
    loadingTable: true,
    queriesCount: 1,
    actionCount: 1,
    dataTables: [],
    headers: [],
    desserts: [],
    queries: [{ value: "text one" }],
    actions: [{ value: "Action one" }],
    model: "tab-2",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",

    showLoader: false,
    testnew: true,
    testnew2: false,
    loading: false,
    password: "Password",
    appid: "786ec6d6-d96a-4ba1-951e-ab5be5cd75d0",
    secret: "P9x7Q~0ifS_pPO0uPDXAFm7Wq7e00ZLYulvwI",
    tenant: "1de020a7-e0ae-4802-ab29-72b5bf128b4e",
    subsid: false,
    subscriptions: false,
    resources: false,
    workspaces: false,
    analitcs: false,
    columns: [],
    entities: false,
    subscription: false,
    resource: false,
    workspace: false,
    analytic: false,
    entity: "",
  }),
  methods: {
    selectActionMenu(menuItem) {
      this.dialog = true;
      console.log(menuItem);
    },
    submitAllEntities(entities) {
      entities.forEach((element) => {
        this.submitEntity(element);
      });
    },
    submitEntity(entity) {
      let workspaceFound = this.workspaces.find(
        (pr) => pr.id == this.workspace
      );
      let analyticFound = this.analitcs.find((pr) => pr.id == this.analytic);
      this.showLoader = true;
      this.axios({
        method: "POST",
        url: "http://localhost:8888/editentitysingle",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          subid: this.subscription,
          entity: this.entity,
          workspace: this.workspace,
          analytic: analyticFound.name,
          entity: entity,
        },
      }).then((response) => {
        this.showLoader = false;
        return;
      });
      return;
    },
    sendEntity() {
      let workspaceFound = this.workspaces.find(
        (pr) => pr.id == this.workspace
      );
      let analyticFound = this.analitcs.find((pr) => pr.id == this.analytic);
      this.showLoader = true;
      this.axios({
        method: "POST",
        url: "http://localhost:8888/editentity",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          subid: this.subscription,
          entity: this.entity,
          workspace: workspaceFound.customerId,
          analytic: analyticFound.name,
        },
      }).then((response) => {
        this.showLoader = false;
        console.log(response);
        this.submitAllEntities(response.data.tables[0].rows);
        return;
        const newAnalytics = [];
        for (var i in response.data.value) {
          newAnalytics.push({
            id: response.data.value[i].id,
            label: response.data.value[i].properties.displayName,
          });
        }
        this.analitcs = newAnalytics;
      });
      return;
    },
    selectEntities() {},
    selectColumns() {},
    sendQueries() {
      this.columns = ["col1", "col2", "col3"];
      /*let workspaceFound = this.workspaces.find(
        (pr) => pr.id == this.workspace
      );
      let analyticFound = this.analitcs.find((pr) => pr.id == this.analytic);*/
      this.showLoader = true;
      this.axios({
        method: "POST",
        url: "http://localhost:8888/sendquery",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          //subid: this.subscription,
          //entity: this.entity,
          workspace: "d5998275-8242-4155-b472-b14117eb34ce", //workspaceFound.customerId,
          //analytic: analyticFound.name,
          query: this.queries[0].value,
        },
      }).then((response) => {
        this.showLoader = false;
        const newDataTablesHeader = [];
        const newDataTablesBody = [];
        const columns = [];
        const columnsNamesMenu = [];
        console.log(response.data.tables[0].columns);
        for (var i in response.data.tables[0].columns) {
          columns.push(response.data.tables[0].columns[i].name);
          columnsNamesMenu.push({
            title: response.data.tables[0].columns[i].name,
          });
          newDataTablesHeader.push({
            text: response.data.tables[0].columns[i].name,
            value: response.data.tables[0].columns[i].name,
          });
        }
        for (var i in response.data.tables[0].rows) {
          const newRow = [];
          for (var j in columns) {
            newRow[columns[j]] = response.data.tables[0].rows[i][j];
          }
          console.log(newRow);
          newDataTablesBody.push(newRow);
        }
        //this.dataTables.push(newDataTables);
        this.headers = newDataTablesHeader;
        this.desserts = newDataTablesBody;
        this.items = columnsNamesMenu;
        this.loadingTable = false;
        console.log(this.headers);
        return;
      });
      return;
    },
    selectAnalytics() {
      this.showLoader = true;
      this.axios({
        method: "POST",
        url: "http://localhost:8888/entities",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          subid: this.subscription,
          workspace: this.workspace,
          analytic: this.analytic,
        },
      }).then((response) => {
        console.log(response);
        this.showLoader = false;
        return;
        const newAnalytics = [];
        for (var i in response.data.value) {
          newAnalytics.push({
            id: response.data.value[i].id,
            label: response.data.value[i].properties.displayName,
          });
        }
        this.analitcs = newAnalytics;
      });
      return;
    },
    changeAction(action) {
      switch (action) {
        case "plus":
          this.actionCount++;
          this.actions.push({ value: "text" });
          break;
        case "minus":
          if (this.actionCount < 2) {
            break;
          }
          this.actions.splice(this.actions.length - 1, 1);
          this.actionCount--;
          break;
      }
    },
    changeQuery(action) {
      switch (action) {
        case "plus":
          if (this.queriesCount > 2) {
            break;
          }
          this.queriesCount++;
          this.queries.push({ value: "text" });
          break;
        case "minus":
          if (this.queriesCount < 2) {
            break;
          }
          this.queries.splice(this.queries.length - 1, 1);
          this.queriesCount--;
          break;
      }
    },
    selectWorkspace() {
      this.showLoader = true;
      //this.analitcs = ["analitics1", "analitics2"];
      this.axios({
        method: "POST",
        url: "http://localhost:8888/analytics",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          subid: this.subscription,
          workspace: this.workspace,
          resource: this.resource,
        },
      }).then((response) => {
        const newAnalytics = [];
        for (var i in response.data.value) {
          newAnalytics.push({
            id: response.data.value[i].id,
            label: response.data.value[i].properties.displayName,
            name: response.data.value[i].name,
          });
        }
        this.analitcs = newAnalytics;
        this.showLoader = false;
      });
      return;
    },
    selectResource() {
      this.showLoader = true;
      //this.workspaces = ["workspace1", "workspace2"];
      this.axios({
        method: "POST",
        url: "http://localhost:8888/workspaces",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          subid: this.subscription,
        },
      }).then((response) => {
        const newWorkspaces = [];
        for (var i in response.data.value) {
          newWorkspaces.push({
            id: response.data.value[i].id,
            label: response.data.value[i].name,
            customerId: response.data.value[i].properties.customerId,
          });
        }
        this.workspaces = newWorkspaces;
        this.showLoader = false;
      });
      return;
    },
    selectSubscription() {
      this.showLoader = true;
      //this.resources = ["resource1", "resource2"];
      this.axios({
        method: "POST",
        url: "http://localhost:8888/resources",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
          subid: this.subscription,
        },
      }).then((response) => {
        const newGroups = [];
        for (var i in response.data.value) {
          newGroups.push({
            id: response.data.value[i].id,
            label: response.data.value[i].name,
          });
        }
        this.resources = newGroups;
        this.showLoader = false;
      });
      return;
    },
    validate() {
      this.loading = true;
      //this.subscriptions = ["subscription1", "subscription2"];
      this.axios({
        method: "POST",
        url: "http://localhost:8888/",
        data: {
          appId: this.appid,
          secret: this.secret,
          tenant: this.tenant,
        },
      }).then((response) => {
        const newSubsciptions = [];
        for (var i in response.data.value) {
          newSubsciptions.push({
            id: response.data.value[i].subscriptionId,
            label: response.data.value[i].displayName,
          });
        }
        this.subscriptions = newSubsciptions;
        this.loading = false;
      });
      return;
      //const msrest = require('ms-rest');
      const msRestAzure = require("ms-rest-azure");
      const AzureServiceClient = msRestAzure.AzureServiceClient;

      const clientId = this.appid;
      const secret = this.secret;
      const domain = this.tenant;
      const subscriptionId = this.subsid;
      var client;

      //an example to list resource groups in a subscription
      msRestAzure
        .loginWithServicePrincipalSecret(clientId, secret, domain)
        .then((creds) => {
          client = new AzureServiceClient(creds);
          let options = {
            method: "GET",
            url: "https://management.azure.com/subscriptions?api-version=2020-01-01",
            headers: {
              "user-agent": "MyTestApp/1.0",
            },
          };
          return client.sendRequest(options);
        })
        .then((result) => {
          console.dir(result, { depth: null, colors: true });
        })
        .catch((err) => {
          console.dir(err, { depth: null, colors: true });
        });

      //this.$refs.form.validate()
    },
  },
};
</script>
